<?php
// created: 2018-08-15 11:18:10
$unified_search_modules_display = array (
  'Accounts' => 
  array (
    'visible' => true,
  ),
  'Contacts' => 
  array (
    'visible' => true,
  ),
  'Opportunities' => 
  array (
    'visible' => true,
  ),
  'Calls' => 
  array (
    'visible' => true,
  ),
  'Documents' => 
  array (
    'visible' => true,
  ),
  'Cases' => 
  array (
    'visible' => true,
  ),
  'AOS_Contracts' => 
  array (
    'visible' => true,
  ),
  'Leads' => 
  array (
    'visible' => true,
  ),
  'Meetings' => 
  array (
    'visible' => true,
  ),
  'Notes' => 
  array (
    'visible' => true,
  ),
  'Campaigns' => 
  array (
    'visible' => true,
  ),
  'AOP_Case_Events' => 
  array (
    'visible' => false,
  ),
  'AOP_Case_Updates' => 
  array (
    'visible' => false,
  ),
  'AOR_Reports' => 
  array (
    'visible' => false,
  ),
  'AOS_Invoices' => 
  array (
    'visible' => false,
  ),
  'AOS_PDF_Templates' => 
  array (
    'visible' => false,
  ),
  'AOS_Product_Categories' => 
  array (
    'visible' => false,
  ),
  'AOS_Products' => 
  array (
    'visible' => false,
  ),
  'AOS_Quotes' => 
  array (
    'visible' => false,
  ),
  'AOW_Processed' => 
  array (
    'visible' => false,
  ),
  'AOW_WorkFlow' => 
  array (
    'visible' => false,
  ),
  'Bugs' => 
  array (
    'visible' => false,
  ),
  'Calls_Reschedule' => 
  array (
    'visible' => false,
  ),
  'FP_Event_Locations' => 
  array (
    'visible' => false,
  ),
  'FP_events' => 
  array (
    'visible' => false,
  ),
  'Project' => 
  array (
    'visible' => false,
  ),
  'ProjectTask' => 
  array (
    'visible' => false,
  ),
  'ProspectLists' => 
  array (
    'visible' => false,
  ),
  'Prospects' => 
  array (
    'visible' => false,
  ),
  'Tasks' => 
  array (
    'visible' => false,
  ),
  'jjwg_Address_Cache' => 
  array (
    'visible' => false,
  ),
  'jjwg_Areas' => 
  array (
    'visible' => false,
  ),
  'jjwg_Maps' => 
  array (
    'visible' => false,
  ),
  'jjwg_Markers' => 
  array (
    'visible' => false,
  ),
);