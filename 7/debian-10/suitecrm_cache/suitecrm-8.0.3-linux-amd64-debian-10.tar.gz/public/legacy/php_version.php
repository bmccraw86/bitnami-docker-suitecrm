<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

// The absolute minimum version on which to install SuiteCRM
define('SUITECRM_PHP_MIN_VERSION', '7.2.9');

// The minimum recommended version on which to install SuiteCRM
define('SUITECRM_PHP_REC_VERSION', '7.3.0');
